// Null JS
console.log("Null JS");
