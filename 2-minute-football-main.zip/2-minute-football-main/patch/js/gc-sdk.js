FB= {
  "login": function() {
    console.log("--fx--gc-sdk--FB--login--")
  }
}
